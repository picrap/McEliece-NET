﻿using System;
using VTDev.Libraries.CEXEngine.Crypto.Cipher.Asymmetric.Interfaces;
using VTDev.Libraries.CEXEngine.Crypto.Cipher.Asymmetric.McEliece;
using VTDev.Libraries.CEXEngine.Tools;
using System.IO;

namespace Test.Tests
{
    /// <summary>
    /// Test the validity of the McEliece Parameters implementation
    /// </summary>
    public class McElieceParamTest : ITest
    {
        #region Constants
        private const string DESCRIPTION = "Test the validity of the McEliece Parameters implementation";
        private const string FAILURE = "FAILURE! ";
        private const string SUCCESS = "SUCCESS! Parameters tests have executed succesfully.";
        #endregion

        #region Events
        public event EventHandler<TestEventArgs> Progress;
        protected virtual void OnProgress(TestEventArgs e)
        {
            var handler = Progress;
            if (handler != null) handler(this, e);
        }
        #endregion

        #region Properties
        /// <summary>
        /// Get: Test Description
        /// </summary>
        public string Description { get { return DESCRIPTION; } }
        #endregion

        #region Public Methods
        /// <summary>
        /// Tests the validity of the EncryptionKey implementation
        /// </summary>
        /// 
        /// <returns>State</returns>
        public string Test()
        {
            try
            {
                TestParams();
                OnProgress(new TestEventArgs("Passed parameters comparison tests"));

                return SUCCESS;
            }
            catch (Exception Ex)
            {
                string message = Ex.Message == null ? "" : Ex.Message;
                throw new Exception(FAILURE + message);
            }
        }
        #endregion

        #region Private Methods
        private void TestParams()
        {
            MPKCParameters mpar = new MPKCParameters(11, 40);
            byte[] enc = mpar.ToBytes();

            using (MPKCParameters mpar2 = MPKCParameters.Read(enc))
            {
                if (!mpar.Equals(mpar2))
                    throw new Exception("EncryptionKey: public key comparison test failed!");
            }
            OnProgress(new TestEventArgs("Passed parameters byte serialization"));

            MemoryStream mstr = mpar.ToStream();
            using (MPKCParameters mpar2 = MPKCParameters.Read(mstr))
            {
                if (!mpar.Equals(mpar2))
                    throw new Exception("EncryptionKey: public key comparison test failed!");
            }
            OnProgress(new TestEventArgs("Passed parameters stream serialization"));
        }
        #endregion
    }
}
